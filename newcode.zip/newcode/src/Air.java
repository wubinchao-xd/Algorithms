/**
 * 
 */

/**
 * @author WuBinChao
 *2018��8��25��
 * ����11:15:53
 */
public class Air {

	/**
	 * @param args
	 */
	
//	int a[maxn],dp[maxn];
//	int n;
//	int bsearch(int len,int x)
//	{
//	    int l=0,r=len-1;
//	    while(l<=r)
//	    {
//	        int mid=(l+r)/2;
//	        if(x>=dp[mid-1]&&x<dp[mid])return mid;
//	        else if(x<dp[mid-1])r=mid-1;
//	        else l=mid+1;
//	    }
//	    return l;
//	}
//	int LIS()
//	{
//	    dp[0]=a[0];
//	    int len=1;
//	    int j;
//	    for(int i=1; i<n; i++)
//	    {
//	        if(a[i]<dp[0])j=0;
//	        else if(a[i]>=dp[len-1])j=len++;
//	        else j=bsearch(len,a[i]);
//	        dp[j]=a[i];
//	    }
//	    return len;
//	}

	
//	int lis(vector<int> &nums){
//	    vector<int> rets(nums.size(),1);
//	    int len=1;
//	    for(int i=1;i!=nums.size();i++){
//	        for(int j=0;j!=i;j++){
//	            if(nums[j]<nums[i])
//	                rets[i]=Math.max(rets[i],rets[j]+1);
//	        }
//	        if(rets[i]>len)
//	            len=rets[i];
//	    }
//	    return len;
//	}


	    public static int[] getLen(int[] arr,int n){
	         int len=0;
//	         arr=new int[n];//���������
	         int[] dp=new int[n];//��¼�Ե�i������β�������еĳ���
	         for(int i=0;i<n;i++){
	             dp[i]=1;//Ĭ�������κ��Ե�i������β�������еķǵݼ��ĳ�����1(��ʼ״̬)
	             for(int j=0;j<i;j++){
	                 if(arr[i]>=arr[j]&&(dp[i]<dp[j]+1))//Ѱ��ǰ���arr[i]С�������У�Ѱ�������������ĳ���
	                     dp[i]=dp[j]+1;
	             }
             len=dp[i]>len?dp[i]:len;
	         }
	         return dp;
	    }
	    
	    public static void main(String[] args) {
	        int[] arr={10,3,7,5,10,3,7,5,10,3,7,5,10,3,7,5};
	        int[] a=getLen(arr, 16);
	        System.out.println(a.length);
	        for(int i=0;i<a.length;i++){
	            System.out.println(a[i]);
	        }
	        System.out.println(getLen(arr, 16));
	    }
	}



/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
import java.util.*;
public class Main2 {
    public static void main(String[] args) {
          Scanner in = new Scanner(System.in);
       String string=in.nextLine();
        int n=string.length();
        Main2 ma=new Main2();
       System.out.print(ma.fun(string));
    }

  public int fun(String string){
	  int n=string.length();
	  int sum=0;
	  for(int i=1;i<n;i++){
		  sum=sum+i*(n-i);
	  }
	  char[] c=string.toCharArray();
	  int k=string.indexOf('0');
    if(c[0]=='0'){
		  
		  for(int i=1;i<n;i++)
			  sum=sum+i;   
		   System.out.println(sum);
		   return sum;
	  }
    if(k>0){
    	sum=sum-k*(n-k-1);
    	return sum;
    }

	  return sum;
  }
    
}
import java.util.Arrays;
import java.util.Scanner;

/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
public class ThreeNumberSumOfN extends TwoNumberSumEqualN{
	
	public static Boolean Find(int[] array,int sum) {
		boolean flag=false;
		for(int i=0;i<array.length;i++){
			int sumDescOnesum=sum-array[i];
			flag=TwoNumberSumEqualN.Find(array,sumDescOnesum);
		}
		return flag;
	}
	public static void main(String[] args) {
		int[]a={-3,-4,-6,0,4,6,3,1};
		Scanner scanner=new Scanner(System.in);
		char[]array=scanner.nextLine().toCharArray();
		int[] ar=new int[array.length];
		for(int i:array){
			ar[i]=array[i]-'0';
		}
		Arrays.sort(ar, 0, ar.length); 
		 Find(ar, 5);

	}
}

import java.util.Arrays;
import java.util.Scanner;

/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
public class TwoNumberSumEqualN {
	
	public static Boolean Find(int[] arr, int sum)
    {
        // ����������
        
          for(int i=0;i<arr.length;i++){
        	  System.out.print(arr[i]);
          }
          System.out.println();
        int first = 0;
        int last=arr.length-1 ;

        while (  first<last )
        {
            // �ҵ�
            if(arr[last] + arr[first]  == sum)
            {
                System.out.println(arr[first]+"+"+arr[last]+"="+sum);           
                return true;
            }
            else if(arr[first] + arr[last] > sum)
            {
                --last;
            }
            else // (arr[i] + arr[j]  < sum)
            {
                ++first;
            }
        }

        // goes here     
        System.out.println("δ�ҵ��� "); 
        return false;
}

	public static void main(String[] args) {
		int[]a={-3,-4,-6,0,4,6,3,1};
		Scanner scanner=new Scanner(System.in);
		char[]array=scanner.nextLine().toCharArray();
		int[] ar=new int[array.length];
		for(int i=0;i<ar.length;i++){
			ar[i]=array[i]-'0';
		}
		Arrays.sort(ar, 0, ar.length); 
		TwoNumberSumEqualN.Find(a, 5);

	}

}

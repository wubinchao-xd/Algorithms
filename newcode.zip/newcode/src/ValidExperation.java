import java.util.Scanner;

/**
 * 
 */

/**
 * @author WuBinChao
 *2018��8��25��
 * ����10:47:20
 */
public class ValidExperation {

	
	  
	    public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);
	            int n = in.nextInt();
	            
	            System.out.println(ValidNumber(n));
	        
	    }
      
	    
	    public static int ValidNumber(int n){	
	    	int number=1;
	    	for(int i=0;i<n;i++){
	    		number=number*10;
	    	}
	    
	    	return number;
	    }

}

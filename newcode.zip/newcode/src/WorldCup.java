import java.util.ArrayList;
import java.util.Scanner;

/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
public class WorldCup {

	public static void main(String[] args) {
		 String str = "1, 1, 2, 3"; 
		 Scanner scanner=new Scanner(System.in);
		 int m=scanner.nextInt();
		 int n=scanner.nextInt();
		 String[] string=new String[m];
		 int[][] intAry=new int[m][n];
		 for(int i = 0; i < m; i++){
			 string[i]=scanner.nextLine();
		 }
		     
		 for(int j=0;j<n;j++){
			 String[] strAry = string[j].split(","); 
		 }
		  for(int i = 0; i < intAry.length; i++){
		  System.out.println(intAry[i]);
		  }

	}

}
class Node{
	int x;
	int y;
	public boolean findNext(ArrayList<Node> nodeArrays,ArrayList<Node> nodes) {
		boolean flag=false;
		for(int i=0;i<nodeArrays.size();i++){
			Node node=nodeArrays.get(i);
			if(node.x-x<2&&node.y-y<2)
				nodes.add(node);
		}
			
		return false;
	}
}
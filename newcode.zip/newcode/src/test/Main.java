package test;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
public class Main{
    public double fun(int n,int m){
      double result=0.0;
      double temp=n;
      for(int i=0;i<m;i++){
    	  result=result+temp;
    	  temp=Math.sqrt(temp);  
      }
      return result;
    }
public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
     while(sc.hasNext()){
     int n=sc.nextInt();
     int m=sc.nextInt(); 
     Main main=new Main();
     DecimalFormat df = new DecimalFormat(".00");
     System.out.println(df.format(main.fun(n,m)));
     }
    
 }
}
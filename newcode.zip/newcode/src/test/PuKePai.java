package test;

import java.util.Scanner;

/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
public class PuKePai {

	
}
class Main2{
    public static  int min(int n,int[]a){
      int result=0;
      int min=Integer.MAX_VALUE;
      for(int i=0;i<n;i++){
    	  if(a[i]<min)
    		  min=a[i];
    	  result=result+a[i];
      }
      result=result-min;
      return result;
    }
public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
       String n=sc.nextLine();
       int[] a=new int[13];
       for(int i=0;i<13;i++){
    	   a[i]=sc.nextInt();
       }
     Main2 main=new Main2();
      System.out.println(min(13,a));
    
 }
}
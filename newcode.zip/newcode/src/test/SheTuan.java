package test;
import java.util.Arrays;
/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
import java.util.Scanner;

public class SheTuan{
    public static int fun(int n,int[]start,int[]end){
      int result=0;
     Arrays.sort(start);
      for(int i=0;i<n;i++){
    	 
      }
      return result;
    }
public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
     int n=sc.nextInt();
     int[]start=new int[n];
     int[]end=new int[n];
     for(int i=0;i<n;i++){
    	 start[i]=sc.nextInt();
    	 end[i]=sc.nextInt();
     }
     int result=fun(n,start,end);
      
     System.out.println(result);
     }
    
 }

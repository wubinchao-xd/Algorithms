package test;

import java.util.Scanner;

/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
public class XiuLu {

}
 class Main1{
    public static int min(char[]a){
      int result=4;
      return result;
    }
public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
       String string=sc.nextLine();
      System.out.println(string.toCharArray());
    
 }
}
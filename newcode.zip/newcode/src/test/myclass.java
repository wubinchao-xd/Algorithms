package test;

import toOffer.TwoStackToQueue;

/**
 * @ClassName: 
 * @Description:
 * @author: 
 * @date: 
 */
public class myclass {

	public static void main(String[] args) {
		String s="xiaobaobei";
		System.out.println(s.substring(0, s.length()));
		int a=123;
		System.out.println(a);
		System.out.println("Ц��������Ӧ�ı��");
//		String str1="hello";
//		String str2="he"+ new String("llo");
//		System.out.println(str1==str2);
		
		int i = 5;
		int j = 10;
		System.out.println(i + ~j);
		TwoStackToQueue queue=new TwoStackToQueue();
		queue.push(1);
		queue.push(2);
		queue.push(3);
		System.out.print(queue.pop());
		System.out.print(queue.pop());
		System.out.print(queue.pop());
		
	}

}
